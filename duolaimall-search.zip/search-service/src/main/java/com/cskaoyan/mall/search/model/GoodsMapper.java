package com.cskaoyan.mall.search.model;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface GoodsMapper extends BaseMapper<Goods> {
}
