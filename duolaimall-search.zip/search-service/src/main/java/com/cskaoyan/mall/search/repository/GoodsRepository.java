package com.cskaoyan.mall.search.repository;

import com.cskaoyan.mall.search.model.Goods;
import org.springframework.data.repository.CrudRepository;

public interface GoodsRepository extends CrudRepository<Goods,Long> {

}
